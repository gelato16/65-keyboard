/*
Copyright 2011 Jun Wako <wakojun@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SENDCHAR_H
#define SENDCHAR_H

#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

/* transmit a character.  return 0 on success, -1 on error. */
int8_t sendchar(uint8_t c);

#ifdef __cplusplus
}
#endif

#endif
